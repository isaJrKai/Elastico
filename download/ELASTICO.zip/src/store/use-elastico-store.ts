import { create } from 'zustand'

// ── Types ────────────────────────────────────────────────────────────────────

export type View =
  | 'login'
  | 'dashboard'
  | 'matches'
  | 'match-detail'
  | 'predictions'
  | 'leaderboard'
  | 'news'
  | 'tournament'
  | 'admin'
  | 'settings'
  | 'subscription'
  | 'notifications'
  | 'profile'
  | 'ai-chat'
  | 'tactical'
  | 'players'
  | 'compare'
  | 'achievements'
  | 'export'
  | 'social'
  | 'prediction-engine'
  | 'system-monitor'

export interface User {
  id: string
  email: string
  name: string | null
  displayName: string | null
  avatarUrl: string | null
  role: string
  plan: string
  predictionAccuracy: number
  predictionStreak: number
  bestStreak: number
  totalPredictions: number
  correctPredictions: number
  achievements: string
  favoriteTeams: string
  twoFactorEnabled: boolean
  lastLoginAt: string | null
  loginCount: number
}

export interface Match {
  id: string
  homeTeamId: string
  awayTeamId: string
  competition: string
  stage: string
  group: string | null
  date: string | null
  status: string
  homeScore: number
  awayScore: number
  homeXg: number
  awayXg: number
  possessionHome: number
  shotsHome: number
  shotsAway: number
  shotsOnTargetHome: number
  shotsOnTargetAway: number
  cornersHome: number
  cornersAway: number
  foulsHome: number
  foulsAway: number
  venue: string | null
  weather: string | null
  temperature: number | null
  homeWinProb: number | null
  drawProb: number | null
  awayWinProb: number | null
  homeEloBefore: number | null
  awayEloBefore: number | null
  isSimulated: boolean
  homeTeam?: Team
  awayTeam?: Team
  events?: MatchEvent[]
  _count?: { predictions: number; votes: number; bookmarks: number }
}

export interface Team {
  id: string
  name: string
  code: string
  primaryColor: string
  secondaryColor: string
  eloRating: number
  form: string
  wins: number
  draws: number
  losses: number
  goalsFor: number
  goalsAgainst: number
  group: string | null
  rank: number | null
  coachName: string | null
  style: string | null
  xgPerGame: number
  xgaPerGame: number
  possession: number
  passAccuracy: number
  pressIntensity: number
  players?: Player[]
}

export interface Player {
  id: string
  name: string
  number: number
  position: string
  goals: number
  assists: number
  yellowCards: number
  redCards: number
  rating: number
  marketValue: number | null
  age: number | null
}

export interface MatchEvent {
  id: string
  minute: number
  type: string
  team: string
  playerName: string
  description: string | null
}

export interface NewsItem {
  id: string
  title: string
  summary: string | null
  content: string | null
  source: string | null
  category: string
  isBreaking: boolean
  sentiment: string | null
  publishedAt: string | null
  reactions: string
}

export interface ChatMessage {
  id: string
  role: 'user' | 'assistant'
  content: string
  timestamp: number
}

export interface Notification {
  id: string
  type: string
  title: string
  message: string
  isRead: boolean
  createdAt: string
}

// ── Store Interface ──────────────────────────────────────────────────────────

interface ElasticoStore {
  // Auth
  user: User | null
  token: string | null
  isAuthenticated: boolean

  // Navigation
  currentView: View
  selectedMatchId: string | null
  sidebarOpen: boolean
  commandPaletteOpen: boolean

  // Data
  matches: Match[]
  teams: Team[]
  news: NewsItem[]
  notifications: Notification[]
  chatMessages: ChatMessage[]

  // UI State
  isLoading: boolean
  loadingMessage: string
  theme: 'dark' | 'light'

  // Actions - Auth
  setUser: (user: User | null, token: string | null) => void
  logout: () => void

  // Actions - Navigation
  setView: (view: View) => void
  selectMatch: (matchId: string | null) => void
  toggleSidebar: () => void
  setSidebarOpen: (open: boolean) => void
  toggleCommandPalette: () => void
  setCommandPaletteOpen: (open: boolean) => void

  // Actions - Data
  setMatches: (matches: Match[]) => void
  setTeams: (teams: Team[]) => void
  setNews: (news: NewsItem[]) => void
  setNotifications: (notifications: Notification[]) => void
  addChatMessage: (message: ChatMessage) => void
  updateChatMessage: (id: string, updates: Partial<ChatMessage>) => void
  clearChat: () => void

  // Actions - UI
  setLoading: (loading: boolean, message?: string) => void
  setTheme: (theme: 'dark' | 'light') => void

  // Actions - Real-time updates
  updateMatch: (match: Partial<Match> & { id: string }) => void
  addNotification: (notification: Notification) => void
  markNotificationRead: (id: string) => void

  // Actions - Data Fetching
  fetchMatches: () => Promise<void>
  fetchTeams: () => Promise<void>
  fetchNews: () => Promise<void>
  fetchNotifications: () => Promise<void>
  fetchAnnouncements: () => Promise<void>
}

// ── Store ────────────────────────────────────────────────────────────────────

export const useElasticoStore = create<ElasticoStore>()((set, get) => ({
  // ── Initial State ─────────────────────────────────────────────────────────

  // Auth
  user: null,
  token: null,
  isAuthenticated: false,

  // Navigation
  currentView: 'login',
  selectedMatchId: null,
  sidebarOpen: false,
  commandPaletteOpen: false,

  // Data
  matches: [],
  teams: [],
  news: [],
  notifications: [],
  chatMessages: [],

  // UI State
  isLoading: false,
  loadingMessage: '',
  theme: 'dark',

  // ── Actions — Auth ────────────────────────────────────────────────────────

  setUser: (user, token) =>
    set({
      user,
      token,
      isAuthenticated: user !== null && token !== null,
    }),

  logout: () => {
    if (typeof window !== 'undefined') {
      localStorage.removeItem('elastico_token')
      localStorage.removeItem('elastico_user')
    }
    set({
      user: null,
      token: null,
      isAuthenticated: false,
      currentView: 'login',
      selectedMatchId: null,
      matches: [],
      teams: [],
      news: [],
      notifications: [],
      chatMessages: [],
      isLoading: false,
      loadingMessage: '',
    })
  },

  // ── Actions — Navigation ──────────────────────────────────────────────────

  setView: (view) => set({ currentView: view }),

  selectMatch: (matchId) =>
    set({
      selectedMatchId: matchId,
      currentView: matchId ? 'match-detail' : get().currentView,
    }),

  toggleSidebar: () => set((state) => ({ sidebarOpen: !state.sidebarOpen })),

  setSidebarOpen: (open) => set({ sidebarOpen: open }),

  toggleCommandPalette: () =>
    set((state) => ({ commandPaletteOpen: !state.commandPaletteOpen })),

  setCommandPaletteOpen: (open) => set({ commandPaletteOpen: open }),

  // ── Actions — Data ────────────────────────────────────────────────────────

  setMatches: (matches) => set({ matches }),

  setTeams: (teams) => set({ teams }),

  setNews: (news) => set({ news }),

  setNotifications: (notifications) => set({ notifications }),

  addChatMessage: (message) =>
    set((state) => ({ chatMessages: [...state.chatMessages, message] })),

  updateChatMessage: (id, updates) =>
    set((state) => ({
      chatMessages: state.chatMessages.map((msg) =>
        msg.id === id ? { ...msg, ...updates } : msg,
      ),
    })),

  clearChat: () => set({ chatMessages: [] }),

  // ── Actions — UI ──────────────────────────────────────────────────────────

  setLoading: (loading, message = '') =>
    set({ isLoading: loading, loadingMessage: message }),

  setTheme: (theme) => set({ theme }),

  // ── Actions — Real-time Updates ───────────────────────────────────────────

  updateMatch: (updatedMatch) =>
    set((state) => ({
      matches: state.matches.map((match) =>
        match.id === updatedMatch.id ? { ...match, ...updatedMatch } : match,
      ),
    })),

  addNotification: (notification) =>
    set((state) => ({
      notifications: [notification, ...state.notifications],
    })),

  markNotificationRead: (id) =>
    set((state) => ({
      notifications: state.notifications.map((n) =>
        n.id === id ? { ...n, isRead: true } : n,
      ),
    })),

  // ── Actions — Data Fetching ─────────────────────────────────────────────

  fetchMatches: async () => {
    try {
      const token = get().token
      const headers: Record<string, string> = { 'Accept-Encoding': 'gzip, deflate' }
      if (token) headers['Authorization'] = `Bearer ${token}`
      const res = await fetch('/api/matches', { headers })
      if (res.ok) {
        const data = await res.json()
        const matches = Array.isArray(data) ? data : data.matches || []
        // Track bandwidth
        const payloadBytes = res.headers.get('X-Payload-Bytes')
        if (payloadBytes) {
          try { (
            await import('@/lib/compressed-data-stream')
          ).BandwidthTracker.log(parseInt(payloadBytes, 10), '/api/matches') } catch {}
        }
        set({ matches })
      }
    } catch (e) { console.error('Failed to fetch matches:', e) }
  },

  fetchTeams: async () => {
    try {
      const res = await fetch('/api/teams', { headers: { 'Accept-Encoding': 'gzip, deflate' } })
      if (res.ok) {
        const data = await res.json()
        const teams = Array.isArray(data) ? data : data.teams || []
        const payloadBytes = res.headers.get('X-Payload-Bytes')
        if (payloadBytes) {
          try { (await import('@/lib/compressed-data-stream')).BandwidthTracker.log(parseInt(payloadBytes, 10), '/api/teams') } catch {}
        }
        set({ teams })
      }
    } catch (e) { console.error('Failed to fetch teams:', e) }
  },

  fetchNews: async () => {
    try {
      const res = await fetch('/api/news?limit=30', { headers: { 'Accept-Encoding': 'gzip, deflate' } })
      if (res.ok) {
        const data = await res.json()
        const news = Array.isArray(data) ? data : data.news || []
        const payloadBytes = res.headers.get('X-Payload-Bytes')
        if (payloadBytes) {
          try { (await import('@/lib/compressed-data-stream')).BandwidthTracker.log(parseInt(payloadBytes, 10), '/api/news') } catch {}
        }
        set({ news })
      }
    } catch (e) { console.error('Failed to fetch news:', e) }
  },

  fetchNotifications: async () => {
    try {
      const token = get().token
      if (!token) return
      const res = await fetch('/api/notifications', {
        headers: { Authorization: `Bearer ${token}`, 'Accept-Encoding': 'gzip, deflate' },
      })
      if (res.ok) {
        const data = await res.json()
        const notifications = Array.isArray(data) ? data : data.notifications || []
        const payloadBytes = res.headers.get('X-Payload-Bytes')
        if (payloadBytes) {
          try { (await import('@/lib/compressed-data-stream')).BandwidthTracker.log(parseInt(payloadBytes, 10), '/api/notifications') } catch {}
        }
        set({ notifications })
      }
    } catch (e) { console.error('Failed to fetch notifications:', e) }
  },

  fetchAnnouncements: async () => {
    try {
      const res = await fetch('/api/admin/announcements')
      if (res.ok) {
        const data = await res.json()
        // Announcements are fetched but stored in a separate state if needed
      }
    } catch (e) { /* silent */ }
  },
}))