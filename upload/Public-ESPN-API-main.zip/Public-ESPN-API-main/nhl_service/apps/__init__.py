"""Apps namespace."""
