---
Task ID: 8
Agent: Super Z (Main)
Task: Fix all remaining TypeScript errors and deploy ELASTICO online

Work Log:
- Found 2 hidden mismatched template literal quotes in predictions.ts (backtick open, single-quote close at lines 1002 and 1052) - these caused the parser to enter wrong context
- Fixed the-sports-db.ts: idLeague → id (TSD_LEAGUES items use 'id' number field, not 'idLeague')
- Fixed the-sports-db/route.ts: removed duplicate fetchLeaguesByCountry import, fixed number→string type for league ID
- Fixed predictions/compute/route.ts: added missing 6th argument to dixonColes(), deduplicated 3 TEAM_ELO_MAP keys (LEV, MON, BRE)
- Fixed admin/settings/route.ts: typed results as any[] to fix Prisma upsert inference
- Fixed use-elastico-store.ts: added liveMatches and isLiveLoading to ElasticoStore interface
- Fixed achievements-view.tsx: added missing unlockedAt: null to 11 locked achievement entries
- Fixed dashboard-view.tsx: added missing Cloud import from lucide-react
- Fixed leaderboard-view.tsx: added missing Users import from lucide-react
- Fixed player-view.tsx: null-safety for appearances, imported ReferenceLine, fixed referenceLine→ReferenceLine casing
- Fixed tactical-view.tsx: imported ReferenceLine, fixed referenceLine→ReferenceLine casing
- Fixed social-view.tsx: fixed type incompatibility with unknown cast for feed state setter
- Fixed tournament-view.tsx: fixed isKnockoutStage to accept MatchData, added MatchData→KnockoutMatch converter
- Excluded upload/examples/skills/scripts from tsconfig.json
- TypeScript check: 0 errors
- Next.js build: SUCCESS (all 42 API routes + static pages)
- Git commit and push to Vercel: deployed

Stage Summary:
- 14 files changed, 22 unique bugs fixed
- Zero TypeScript errors, clean build
- Pushed to main branch, Vercel deployment triggered
- System is live and updated
---

## Task 9 — Production readiness audit + fixes (Claude, Aug 2026)

Audited the full app (code, deployment config, security surface) and verified findings by actually running installs/builds/lint rather than reading code alone. Fixed:

1. **Removed `/api/system/veronica-heal`** — a self-modifying-production-code feature
   (server-side `exec` + file writes driven by AI-generated patches). Critical RCE
   risk regardless of admin-gating. Cleaned up all references in `discord-gateway`
   route and `system-monitor-view.tsx` UI.
2. **Fixed Caddy/Docker port mismatch** — Caddyfile listened on `:81`, but
   docker-compose only exposed 80/443. Site was unreachable externally. Caddyfile
   now listens on `:80` with a comment on how to switch to a real domain for
   automatic HTTPS.
3. **Fixed `Dockerfile`** — trailing inline comment on a JSON-array `CMD` line
   (invalid Docker syntax), and switched `npm install` to `npm ci` now that the
   lockfile is back in sync.
4. **Regenerated `package-lock.json`** — was out of sync with `package.json`
   (`npm ci` failed outright before this fix; verified it now succeeds).
5. **Removed unused `next-auth` dependency** — zero usages anywhere in `src/`;
   real auth is the custom JWT/bcrypt system in `src/lib/auth.ts`.
6. **Removed ~72MB of internal artifacts from the public repo**: agent debug
   dumps (`tool-results/`), agent task notes (`agent-ctx/`), agent build scripts
   (`.zscripts/`), an unrelated AI-skill library (`skills/`), and business
   documents including a pitch deck and competitor analysis (`upload/`,
   `download/`). None of this belonged in a public repo.
7. **Removed committed SQLite files** (`prisma/dev.db`, `db/custom.db`) —
   the schema is Postgres-only; these were stale/unused.
8. **Updated `.gitignore`** so none of the above can be re-committed by accident.

### Known follow-ups (not yet done)
- Auth tokens are currently stored in `localStorage`, not an httpOnly cookie —
  vulnerable to token theft via XSS. Worth migrating.
- ~19 ESLint `react-hooks/set-state-in-effect` warnings across several files
  (mostly benign "read a browser value on mount" patterns) — not fixed here,
  low priority.
- Full `next build` could not be verified in this environment because Prisma's
  engine binary download (`binaries.prisma.sh`) was network-blocked in the
  sandbox — `npx prisma generate` fell back to a stub client. This is an
  environment limitation, not a code defect; run `npx prisma generate && npm
  run build` in a normal environment (or your real Docker build) to confirm.

### Future plan (noted by the app owner, not yet implemented)
The owner intends to eventually run a **Nous Hermes agent** as a persistent
in-app agent for chat/Q&A, operating under its own "philosophy"/system prompt.
This will need a dedicated context/knowledge layer the agent reads from (rather
than reaching into raw DB tables directly) so its answers stay consistent with
that philosophy. Not built yet — flagging here so future work (by a human or
by Claude) designs the data/API layer with that in mind rather than needing a
rework later.

---

## Task 10 — Fixed confirmed fabricated-data instances in dashboard-view.tsx (Claude, Aug 2026)

Verified and fixed the two specific "data honesty" issues flagged during the
frontend/intelligence integration review:

1. **xG chart (was line ~108).** Previously computed `xg: (homeScore +
   awayScore) * 0.9` for ESPN-sourced live matches and plotted it on a chart
   labeled "xG vs Actual Goals" — not real xG, just the final score with a
   constant applied. Now the chart only ever plots real `homeXg`/`awayXg`
   from the database (populated via a real provider — see `src/lib/
   understat.ts`, not yet wired to this chart's data source but the correct
   integration point). Matches without real xG are excluded from the chart
   rather than shown with a fabricated value. Added an honest empty state
   ("xG data unavailable...") for when no matches have real xG recorded.
2. **Next-match win probability (was lines 65-70).** Previously fell back to
   a hardcoded `{ home: 40, draw: 28, away: 32 }` whenever `homeWinProb` /
   `drawProb` / `awayWinProb` were null — rendered identically to a real
   model prediction, with no visual distinction. Now checks whether all
   three fields are actually populated (`hasPrediction`); if not, shows a
   clearly-labeled "No model prediction yet for this match" placeholder
   instead of numbers indistinguishable from real output.

Verified with `npx tsc --noEmit` and `npx eslint` on the touched file — both
clean (the one remaining `tsc` error, in `src/lib/auth.ts`, is a known
sandbox artifact from Prisma's engine binary being network-blocked in this
environment, not a real code issue — see Task 9 notes).

### Not done in this pass (see GLM5-INTEGRATION-INSTRUCTIONS.md)
- Wiring the xG chart to `src/lib/understat.ts` for real per-match xG
  (currently just stops fabricating; doesn't yet fetch the real replacement).
- The 48-site `Math.random()` audit across 8 UI view components — flagged,
  not yet gone through file by file.
