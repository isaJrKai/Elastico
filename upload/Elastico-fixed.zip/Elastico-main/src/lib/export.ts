/**
 * ELASTICO Export Utilities
 * Provides CSV generation, match report generation, and file download helpers.
 */

// ── CSV Generation ───────────────────────────────────────────────────────────

/**
 * Generates a CSV string from an array of objects and triggers a download.
 */
export function generateCSV(data: Record<string, unknown>[], filename: string): void {
  if (!data || data.length === 0) return

  const headers = Object.keys(data[0])
  const csvRows: string[] = []

  // Add header row
  csvRows.push(headers.map((h) => `"${h}"`).join(','))

  // Add data rows
  for (const row of data) {
    const values = headers.map((header) => {
      const val = row[header]
      if (val === null || val === undefined) return '""'
      const str = String(val)
      // Escape double quotes by doubling them, wrap in quotes
      const needsQuoting = str.includes(',') || str.includes('"') || str.includes('\n') || str.includes('\r')
      if (needsQuoting) {
        return `"${str.replace(/"/g, '""')}"`
      }
      return str
    })
    csvRows.push(values.join(','))
  }

  const csvContent = csvRows.join('\n')
  downloadBlob(csvContent, `${filename}.csv`, 'text/csv;charset=utf-8;')
}

// ── Match Report Generation ─────────────────────────────────────────────────

interface MatchReportData {
  homeTeam: string
  awayTeam: string
  homeScore: number
  awayScore: number
  date: string
  venue: string
  competition: string
  stage: string
  homeXg: number
  awayXg: number
  possessionHome: number
  shotsHome: number
  shotsAway: number
  shotsOnTargetHome: number
  shotsOnTargetAway: number
  cornersHome: number
  cornersAway: number
}

/**
 * Generates a match report as HTML and triggers a download.
 */
export function generateMatchReport(match: MatchReportData): void {
  const html = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>ELASTICO Match Report - ${match.homeTeam} vs ${match.awayTeam}</title>
  <style>
    * { margin: 0; padding: 0; box-sizing: border-box; }
    body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif; background: #0d1117; color: #e6edf3; padding: 40px; }
    .container { max-width: 800px; margin: 0 auto; }
    .header { text-align: center; margin-bottom: 40px; border-bottom: 2px solid #00e676; padding-bottom: 20px; }
    .header h1 { color: #00e676; font-size: 24px; margin-bottom: 8px; }
    .header .subtitle { color: #8b949e; font-size: 14px; }
    .scoreboard { display: flex; align-items: center; justify-content: center; gap: 40px; margin: 40px 0; background: #161b22; border-radius: 12px; padding: 32px; border: 1px solid #30363d; }
    .team { text-align: center; }
    .team .name { font-size: 20px; font-weight: 700; margin-bottom: 4px; }
    .team .code { color: #8b949e; font-size: 12px; }
    .score { font-size: 48px; font-weight: 900; color: #00e676; }
    .stats-table { width: 100%; border-collapse: collapse; margin-top: 24px; }
    .stats-table th { text-align: left; color: #8b949e; font-size: 12px; text-transform: uppercase; padding: 8px 12px; border-bottom: 1px solid #30363d; }
    .stats-table td { padding: 10px 12px; border-bottom: 1px solid #21262d; }
    .stats-table .label { color: #8b949e; }
    .xg { color: #00b4d8; font-weight: 600; }
    .footer { text-align: center; margin-top: 40px; color: #484f58; font-size: 12px; }
    .badge { display: inline-block; background: #00e67620; color: #00e676; padding: 2px 8px; border-radius: 4px; font-size: 11px; font-weight: 600; }
  </style>
</head>
<body>
  <div class="container">
    <div class="header">
      <h1>⚽ ELASTICO Match Report</h1>
      <div class="subtitle">${match.competition} · ${match.stage} · ${match.date}</div>
    </div>
    <div class="scoreboard">
      <div class="team">
        <div class="name">${match.homeTeam}</div>
        <div class="code">HOME</div>
      </div>
      <div class="score">${match.homeScore} - ${match.awayScore}</div>
      <div class="team">
        <div class="name">${match.awayTeam}</div>
        <div class="code">AWAY</div>
      </div>
    </div>
    <div class="badge">Venue: ${match.venue}</div>
    <table class="stats-table">
      <thead>
        <tr><th>Statistic</th><th>${match.homeTeam}</th><th>${match.awayTeam}</th></tr>
      </thead>
      <tbody>
        <tr><td class="label">xG</td><td class="xg">${match.homeXg.toFixed(2)}</td><td class="xg">${match.awayXg.toFixed(2)}</td></tr>
        <tr><td class="label">Possession</td><td>${match.possessionHome}%</td><td>${100 - match.possessionHome}%</td></tr>
        <tr><td class="label">Shots</td><td>${match.shotsHome}</td><td>${match.shotsAway}</td></tr>
        <tr><td class="label">Shots on Target</td><td>${match.shotsOnTargetHome}</td><td>${match.shotsOnTargetAway}</td></tr>
        <tr><td class="label">Corners</td><td>${match.cornersHome}</td><td>${match.cornersAway}</td></tr>
      </tbody>
    </table>
    <div class="footer">Generated by ELASTICO AI-Powered Football Analytics · ${new Date().toISOString()}</div>
  </div>
</body>
</html>`

  downloadBlob(html, `elastico-report-${match.homeTeam}-vs-${match.awayTeam}.html`, 'text/html')
}

// ── Download Helper ─────────────────────────────────────────────────────────

/**
 * Creates a blob and triggers a file download in the browser.
 */
export function downloadBlob(content: string, filename: string, type: string): void {
  if (typeof window === 'undefined') return

  const blob = new Blob([content], { type })
  const url = URL.createObjectURL(blob)
  const link = document.createElement('a')
  link.href = url
  link.download = filename
  document.body.appendChild(link)
  link.click()
  document.body.removeChild(link)
  URL.revokeObjectURL(url)
}